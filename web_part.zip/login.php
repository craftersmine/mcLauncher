<?php
    require ('configuration.php');
    $nickname = $_GET["user"];
    $userpass = $_GET["pass"];

    $host = $host_cfg;
    $user = $user_cfg;
    $pass = $pass_cfg;
    $db = $db_cfg;

    $userpass_getted = '';

    if($userpass == '')
        die('Bad login');

    $mysql = mysqli_connect($host,$user,$pass,$db);

    if(mysqli_connect_error())
        die('Unable to connect DB ('.mysqli_connect_errno().')');

    $userpass_encrypted_dmd5 = md5(md5($userpass));

    //echo ('Connection initiated! Username = '.$nickname.' Password = '.$userpass_encrypted_dmd5);

    $query = "SELECT $pass_column FROM $user_table WHERE $user_column='$nickname'";
    if($stmt = $mysql->prepare($query))
    {
        $stmt->execute();
        $stmt->bind_result($pass_getted);
        while($stmt->fetch())
        {
            $userpass_getted = $pass_getted;
        }
    }

    if($userpass_getted == $userpass_encrypted_dmd5) {
        srand(time());
        $randNum = rand(1000000000, 2147483647) . rand(1000000000, 2147483647) . rand(0, 9);
        echo $randNum;
        $session = md5($randNum);
        $query_upd_sess = "UPDATE $user_table SET $session_column='$session' WHERE $user_column='$nickname'";
        mysqli_query($mysql, $query_upd_sess);
    }
    else echo ('Bad login');

    echo (':');
?>

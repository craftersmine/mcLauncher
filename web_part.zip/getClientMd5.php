<?php

    require ('configuration.php');

    $clientName = $_GET["client"];
    $md5file = md5_file($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'.zip');
    echo ($md5file);

?>
<?php
require ('clients.php');
foreach ($clients as $key => $client)
{
    echo ($key.'|'.$client . '<br/>');
}
?>
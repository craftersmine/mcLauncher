<?php
require ('configuration.php');

$clientName = $_GET["client"];

$bin = scandir($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/bin/');
$mods = scandir($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/mods/');
$coremods = scandir($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/coremods/');



foreach ($bin as $value)
{

    if ($value != "." && $value != "..") {
        $md5file = md5_file($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/bin/'.$value);
        echo('/bin/' . $value . '<br/>');
    }
}
foreach ($mods as $mod)
{
    $md5file = md5_file($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/mods/'.$mod);
    if ($mod != "." && $mod != "..") {
        echo('/mods/' . $mod . '<br/>');
    }
}
foreach ($coremods as $coremod)
{
    $md5file = md5_file($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/coremods/'.$coremod);
    if ($coremod != "." && $coremod != "..") {
        echo('/coremods/' . $coremod . '<br/>');
    }
}
//$md5file = md5_file($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/client.zip');
echo ('/client.zip')
?>
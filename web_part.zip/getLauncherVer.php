<?php

require ('configuration.php');
echo ($launcher_version);

?>
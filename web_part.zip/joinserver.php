<?php
define('INCLUDE_CHECK',true);
include ("configuration.php");

$sessionid = $_GET['sessionId'];
$user = $_GET['user'];
$serverid = $_GET['serverId'];

$mysql = mysqli_connect($host_cfg,$user_cfg,$pass_cfg,$db_cfg);
$result = mysqli_query($mysql,"Select $user_column From $user_table Where $session_column='$sessionid' And $user_column='$user' And $server_column='$serverid'") or die ("Запрос к базе завершился ошибкой.");

if(mysqli_num_rows($result) == 1){
    echo "OK";
} else {

$result = mysqli_query($mysql,"Update $user_table SET $server_column='$serverid' Where $session_column='$sessionid' And $user_column='$user'") or die ("Запрос к базе завершился ощибкой.");

    if(mysqli_affected_rows($mysql) == 1){
        echo "OK";
    } else {
        echo "Bad login";
    }
}
?>
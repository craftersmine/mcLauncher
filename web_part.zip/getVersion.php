<?php

    require ('configuration.php');
$ver = $launcher_version;
    echo ($ver);

?>